#!/bin/bash
# 현재 AMD 서버에서 ARM 서버로 크론탭 설정을 원격으로 복구하는 스크립트입니다.
NEW_IP="132.145.91.78"
KEY_PATH="/home/ubuntu/oci_pri.pem"

echo "⏳ 새 서버(ARM)의 크론탭 설정을 원격으로 복구 중..."

# 1. 새 서버에 적용할 크론탭 내용을 파일로 만듭니다.
cat << 'EOF' > my_crontab.txt
SHELL=/bin/bash
HOME_DIR=/home/ubuntu
BOT_DIR=/home/ubuntu/dev/telegram-stock-info-noti-bot
UV=/home/ubuntu/.local/bin/uv
LOG_BASE=/home/ubuntu/log

20 1,13 * * * /home/ubuntu/rclone_sync.sh

# 오라클 클라우드 유지
@reboot sleep 20;  bash <(curl -s -L https://gist.githubusercontent.com/Ansen/e45320205faf5786d3282ac880f20bab/raw/onekey-NeverIdle.sh)

####기본 초기화####
0 * * * * bash ~/sh/setInit.sh
*/5 * * * * ~/sh/duckdns.sh >/dev/null 2>&1

##########docker 전환##########
10 9 * * 1-6 docker exec -i daily-52w-hl-stock python /app/app.py
40 15 * * 1-6 docker exec -i daily-52w-hl-stock python /app/app.py
10 6 * * 1-6  docker exec -i us-52w-hl-stock python /app/app.py
23 22 * * 1-6  docker exec -i us-52w-hl-stock python /app/app.py
0 16 * * 1-6  docker exec -i jp-52w-hl-stock python /app/app.py >> $LOG_BASE/logfile.log 2>&1

########## uv 직접 실행 ##########
# 증권사 개별 스크래퍼
# */30 0,5-12,14-23 * * * LOG_DIR=$LOG_BASE/$(date +\%Y\%m\%d) && mkdir -p $LOG_DIR && cd $BOT_DIR && $UV run scrap_main.py >> $LOG_DIR/$(date +\%Y\%m\%d)_scrap_main.log 2>&1

# 네이버 뉴스
*/5 * * * * LOG_DIR=$LOG_BASE/$(date +\%Y\%m\%d) && mkdir -p $LOG_DIR && cd $BOT_DIR && $UV run news.py >> $LOG_DIR/$(date +\%Y\%m\%d)_news.log 2>&1

# 네이버 증권 리서치
*/30 8-15 * * * LOG_DIR=$LOG_BASE/$(date +\%Y\%m\%d) && mkdir -p $LOG_DIR && cd $BOT_DIR && $UV run naver-research.py >> $LOG_DIR/$(date +\%Y\%m\%d)_naver-research.log 2>&1

# 한경 컨센 레포트
*/30 * * * * LOG_DIR=$LOG_BASE/$(date +\%Y\%m\%d) && mkdir -p $LOG_DIR && cd $BOT_DIR && $UV run hankyungconsen.py >> $LOG_DIR/$(date +\%Y\%m\%d)_hankyungconsen.log 2>&1

# Gemini AI Summary (Batch)
# 15,45 0,5-12,13,14-23 * * * cd ~/dev/telegram-stock-info-noti-bot && $UV run run/gemini_summary_batch.py --limit 20 --model "models/gemini-2.0-flash"
# 0,15,30,45 1-4 * * * cd ~/dev/telegram-stock-info-noti-bot && $UV run run/gemini_summary_batch.py --limit 30 --model "models/gemini-2.0-flash"

# 정보봇(INFO-BOT) 관련
35 15 * * * LOG_DIR=$LOG_BASE/$(date +\%Y\%m\%d) && mkdir -p $LOG_DIR && cd ~/dev/telegram-stock-info-bot && $UV run run/fetch_kr_stock_quant_async.py >> $LOG_DIR/$(date +\%Y\%m\%d)_fetch_kr_stock_quant_async.log 2>&1

# 키워드 알림
*/5 * * * * LOG_DIR=$LOG_BASE/$(date +\%Y\%m\%d) && mkdir -p $LOG_DIR && cd ~/dev/telegram-stock-info-noti-bot && $UV run send_report_by_keyword_to_user.py >> $LOG_DIR/$(date +\%Y\%m\%d)_send_report_by_keyword_to_user.log 2>&1
EOF

# 2. 파일을 새 서버로 보냅니다.
scp -i $KEY_PATH -o StrictHostKeyChecking=no my_crontab.txt ubuntu@$NEW_IP:~/my_crontab.txt

# 3. 새 서버에서 해당 파일을 크론탭에 등록합니다.
ssh -i $KEY_PATH -o StrictHostKeyChecking=no ubuntu@$NEW_IP "crontab ~/my_crontab.txt && rm ~/my_crontab.txt"

echo "✅ 모든 작업이 완료되었습니다!"
echo "새 서버(132.145.91.78)에서 'crontab -l' 명령어로 확인해 보세요."
