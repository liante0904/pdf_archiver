import sqlite3
import os
import re
import subprocess
import json
from pathlib import Path

# --- 설정 ---
DB_PATH = os.path.expanduser("~/sqlite3/telegram.db")
RCLONE_BIN = os.path.expanduser("~/.local/bin/rclone")
REMOTE_ROOT = "onedrive:/archive/pdf"

def clean_title(title):
    if not title: return "no_title"
    text = re.sub(r'\[.*?\]|\(.*?\)|\【.*?\】', '', title)
    text = re.sub(r'[\\/:*?"<>|!@#$%^&*.ⓒ,]', ' ', text)
    return "_".join(text.split())[:60].strip('_')

def fix_onedrive_structure():
    # 1. 원드라이브 루트 폴더의 파일 목록 가져오기 (JSON)
    print("원드라이브 루트 파일 목록 조회 중...")
    cmd = [RCLONE_BIN, "lsjson", REMOTE_ROOT, "--max-depth", "1"]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error: {result.stderr}")
        return

    files = json.loads(result.stdout)
    
    # 2. DB 연결
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    move_count = 0
    for f in files:
        filename = f['Name']
        if not filename.endswith('.pdf') or '.tmp' in filename:
            continue
        
        # report_id 추출 (ID.pdf)
        report_id = filename.replace('.pdf', '')
        if not report_id.isdigit():
            continue
            
        # 3. DB에서 메타데이터 조회
        cursor.execute("""
            SELECT FIRM_NM, ARTICLE_TITLE, REG_DT 
            FROM data_main_daily_send 
            WHERE report_id = ? 
            LIMIT 1
        """, (report_id,))
        
        row = cursor.fetchone()
        if not row:
            print(f"DB에 정보 없음 (건너뜀): {filename}")
            continue
            
        firm, title, reg_dt = row
        clean_dt = re.sub(r'[^0-9]', '', str(reg_dt)) if reg_dt else "00000000"
        y_m = f"{clean_dt[:4]}-{clean_dt[4:6]}"
        yy_mm_dd = clean_dt[2:8]
        
        # 4. 올바른 경로 생성
        new_filename = f"{yy_mm_dd}_{clean_title(title)}_{report_id}.pdf"
        target_path = f"{REMOTE_ROOT}/{y_m}/{firm}/{new_filename}"
        source_path = f"{REMOTE_ROOT}/{filename}"
        
        # 5. rclone moveto 실행
        print(f"이동: {filename} -> {y_m}/{firm}/{new_filename}")
        move_cmd = [RCLONE_BIN, "moveto", source_path, target_path, "--quiet"]
        res = subprocess.run(move_cmd)
        
        if res.returncode == 0:
            move_count += 1
        
        if move_count % 50 == 0:
            print(f"현재 {move_count}개 파일 이동 완료...")

    conn.close()
    print(f"최종 완료: {move_count}개의 파일이 정상 구조로 이동되었습니다.")

if __name__ == "__main__":
    fix_onedrive_structure()
