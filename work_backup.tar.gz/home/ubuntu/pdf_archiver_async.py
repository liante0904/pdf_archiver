# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "aiohttp",
# ]
# ///

import asyncio
import aiohttp
import sqlite3
import os
import logging
import subprocess
import fcntl
import sys
import re
from pathlib import Path

# --- 환경 및 설정 (8년 차 개발자 요구사항 준수) ---
DB_PATH = os.path.expanduser("~/sqlite3/telegram.db")
LOCAL_BUFFER_DIR = os.path.expanduser("~/downloads/pdf_archive_temp")
RCLONE_BIN = os.path.expanduser("~/.local/bin/rclone")
RCLONE_REMOTE = "onedrive:/archive/pdf"
LOCK_FILE = "/tmp/pdf_archiver_async.lock"

# 임계값 및 성능 설정
BUFFER_SIZE_LIMIT = 1024 * 1024 * 1024  # 1GB
BUFFER_COUNT_LIMIT = 500
MAX_CONCURRENCY = 20

# 로깅 설정 (stdout 최소화, 파일 기록 중심)
LOG_FILE = os.path.expanduser("~/log/pdf_archiver_async.log")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

class DownloadManager:
    def __init__(self):
        self.db_path = DB_PATH
        self.local_dir = Path(LOCAL_BUFFER_DIR)
        self.local_dir.mkdir(parents=True, exist_ok=True)
        
        # Concurrency Control (Semaphore)
        self.semaphore = asyncio.Semaphore(MAX_CONCURRENCY)
        
        # Buffer State Management
        self.buffer_size = 0
        self.buffer_count = 0
        self.buffer_lock = asyncio.Lock()
        self.ready_to_upload = []  # [(id, filename), ...]
        
        self._setup_db()

    def _setup_db(self):
        """DB 최적화: WAL 모드 및 스키마 검증"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            try:
                conn.execute("ALTER TABLE data_main_daily_send ADD COLUMN sync_status INTEGER DEFAULT 0;")
                conn.execute("ALTER TABLE data_main_daily_send ADD COLUMN retry_count INTEGER DEFAULT 0;")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_sync_status ON data_main_daily_send(sync_status);")
            except sqlite3.OperationalError:
                pass
            conn.commit()

    def get_targets(self):
        """Resume 기능: 미완료(0, 1) 및 재시도 3회 미만 데이터 로드"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, report_id, ATTACH_URL, DOWNLOAD_URL, sync_status, retry_count, FIRM_NM, ARTICLE_TITLE, REG_DT
                FROM data_main_daily_send 
                WHERE sync_status IN (0, 1)
                AND report_id IS NOT NULL
                AND (ATTACH_URL IS NOT NULL AND ATTACH_URL != '' OR DOWNLOAD_URL IS NOT NULL AND DOWNLOAD_URL != '')
                AND retry_count < 3
                LIMIT 2000
            """)
            return cursor.fetchall()

    def update_db_batch(self, updates):
        """Batch Commit (1,000건 단위) - I/O 병목 방지"""
        if not updates: return
        with sqlite3.connect(self.db_path) as conn:
            conn.executemany(
                "UPDATE data_main_daily_send SET sync_status = ?, retry_count = ? WHERE id = ?",
                updates
            )
            conn.commit()
        logging.info(f"DB Batch Commit: {len(updates)} records updated.")

    async def flush_to_rclone(self, upload_batch):
        """Rclone move 비동기 실행 및 후처리"""
        loop = asyncio.get_running_loop()
        rclone_cmd = [
            RCLONE_BIN, "move", str(self.local_dir), RCLONE_REMOTE,
            "--transfers", "10", "--checkers", "10", "--quiet", "--ignore-existing", "--delete-empty-src-dirs"
        ]
        
        def run_rclone():
            return subprocess.run(rclone_cmd, capture_output=True, text=True)
            
        result = await loop.run_in_executor(None, run_rclone)
        
        if result.returncode == 0:
            logging.info(f"Rclone Success: {len(upload_batch)} files moved.")
            return [(2, 0, r[0]) for r in upload_batch]
        else:
            logging.error(f"Rclone Error: {result.stderr}")
            return [(1, 0, r[0]) for r in upload_batch]

    async def check_and_flush(self, force=False):
        """Buffer Check (1GB or 500 files)"""
        async with self.buffer_lock:
            if force or self.buffer_size >= BUFFER_SIZE_LIMIT or self.buffer_count >= BUFFER_COUNT_LIMIT:
                if not self.ready_to_upload: return []
                batch = self.ready_to_upload[:]
                self.ready_to_upload, self.buffer_size, self.buffer_count = [], 0, 0
                return await self.flush_to_rclone(batch)
        return []

    def _clean_title(self, title):
        if not title: return "no_title"
        text = re.sub(r'\[.*?\]|\(.*?\)|\【.*?\】', '', title)
        text = re.sub(r'[\\/:*?"<>|!@#$%^&*.ⓒ,]', ' ', text)
        return "_".join(text.split())[:60].strip('_')

    async def download_task(self, session, row):
        row_id, report_id, attach_url, download_url, status, retry, firm, title, reg_dt = row
        url = download_url if download_url else attach_url
        
        clean_dt = re.sub(r'[^0-9]', '', str(reg_dt)) if reg_dt else "00000000"
        y_m = f"{clean_dt[:4]}-{clean_dt[4:6]}"
        yy_mm_dd = clean_dt[2:8]
        
        clean_title = self._clean_title(title)
        filename = f"{yy_mm_dd}_{clean_title}_{report_id}.pdf"
        
        target_dir = self.local_dir / y_m / firm
        target_dir.mkdir(parents=True, exist_ok=True)
        file_path = target_dir / filename
        tmp_path = file_path.with_suffix('.tmp')
        
        if status == 1 and file_path.exists():
            async with self.buffer_lock:
                self.buffer_size += file_path.stat().st_size
                self.buffer_count += 1
                self.ready_to_upload.append((row_id, filename))
            return None

        timeout = aiohttp.ClientTimeout(total=35, connect=5, sock_read=30)
        try:
            async with self.semaphore:
                async with session.get(url, timeout=timeout) as resp:
                    if resp.status in [403, 404]: return (9, retry, row_id)
                    resp.raise_for_status()
                    with open(tmp_path, 'wb') as f:
                        async for chunk in resp.content.iter_chunked(65536): f.write(chunk)
            
            # Magic Number Check
            with open(tmp_path, 'rb') as f:
                if f.read(4) != b'%PDF':
                    os.remove(tmp_path)
                    return (9, retry, row_id)
            
            os.rename(tmp_path, file_path)
            async with self.buffer_lock:
                self.buffer_size += file_path.stat().st_size
                self.buffer_count += 1
                self.ready_to_upload.append((row_id, filename))
            return (1, retry, row_id)
            
        except Exception as e:
            if tmp_path.exists(): os.remove(tmp_path)
            logging.error(f"DW Error {row_id}: {str(e)}")
            return (0 if retry < 2 else 9, retry + 1, row_id)

    async def run(self):
        targets = self.get_targets()
        if not targets: return
        
        logging.info(f"Async Archiver Started: {len(targets)} targets.")
        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
        async with aiohttp.ClientSession(headers=headers, connector=aiohttp.TCPConnector(limit=MAX_CONCURRENCY)) as session:
            db_updates = []
            tasks = [asyncio.create_task(self.download_task(session, r)) for r in targets]
            
            for coro in asyncio.as_completed(tasks):
                res = await coro
                if res: db_updates.append(res)
                
                # Buffer Flush
                rclone_res = await self.check_and_flush()
                if rclone_res: db_updates.extend(rclone_res)
                
                if len(db_updates) >= 1000:
                    self.update_db_batch(db_updates)
                    db_updates = []

            final_res = await self.check_and_flush(force=True)
            if final_res: db_updates.extend(final_res)
            if db_updates: self.update_db_batch(db_updates)

if __name__ == "__main__":
    lock_f = open(LOCK_FILE, 'w')
    try:
        fcntl.lockf(lock_f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError:
        sys.exit(0)
        
    asyncio.run(DownloadManager().run())
